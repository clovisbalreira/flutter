package com.example.cartoes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
