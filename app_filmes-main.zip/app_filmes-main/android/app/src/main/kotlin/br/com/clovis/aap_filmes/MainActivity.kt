package br.com.clovis.aap_filmes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
