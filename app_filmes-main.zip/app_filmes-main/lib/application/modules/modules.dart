import 'package:get/get.dart';

abstract class Module{
  abstract List<GetPage> routers;
}